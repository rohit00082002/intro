<?php
    namespace Application\Controller\Plugin;
     
    use Zend\Mvc\Controller\Plugin\AbstractPlugin;
    use Zend\Controller\Front as a;
     
    class PageTitle extends AbstractPlugin{
    public function doSomething()
    {

    }
}
